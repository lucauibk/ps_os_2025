#include "thread_pool.h"

/*** Hilfsfunktion zum Erstellen eines neuen Job-Queue-Eintrags ***/
static job_queue_entry* create_job(job_function function, job_arg argument) {
    static job_id next_id = 1;
    job_queue_entry* job = malloc(sizeof(job_queue_entry));
    if (!job) {
        perror("malloc");
        exit(EXIT_FAILURE);
    }
    job->id = next_id++;
    job->function = function;
    job->argument = argument;
    job->next = NULL;
    job->status = JOB_PENDING;
    pthread_mutex_init(&job->mutex, NULL);
    pthread_cond_init(&job->cond, NULL);
    return job;
}

/*** **Thread Worker-Funktion**: Arbeitet Jobs aus der Warteschlange ab ***/
static void* thread_worker(void* arg) {
    thread_pool* pool = (thread_pool*) arg;

    while (1) {
        pthread_mutex_lock(&pool->queue_mutex);

        // Warte, falls die Warteschlange leer ist und der Pool nicht zerstört wird
        while (pool->queue == NULL && !pool->shutdown) {
            pthread_cond_wait(&pool->queue_not_empty, &pool->queue_mutex);
        }

        if (pool->shutdown && pool->queue == NULL) {
            pthread_mutex_unlock(&pool->queue_mutex);
            pthread_exit(NULL);
        }

        // Job aus der Warteschlange holen
        job_queue_entry* job = pool->queue;
        if (job) {
            pool->queue = job->next;
        }

        pthread_mutex_unlock(&pool->queue_mutex);

        if (job) {
            // Markiere den Job als laufend
            pthread_mutex_lock(&job->mutex);
            job->status = JOB_RUNNING;
            pthread_mutex_unlock(&job->mutex);

            // Job-Funktion ausführen
            job->function(job->argument);

            // Markiere den Job als fertig
            pthread_mutex_lock(&job->mutex);
            job->status = JOB_DONE;
            pthread_cond_broadcast(&job->cond);
            pthread_mutex_unlock(&job->mutex);

            // Job-Speicher freigeben
            pthread_mutex_destroy(&job->mutex);
            pthread_cond_destroy(&job->cond);
            free(job);
        }
    }
}

/*** **Thread-Pool erstellen** ***/
void pool_create(thread_pool* pool, size_t size) {
    pool->threads = malloc(size * sizeof(pthread_t));
    if (!pool->threads) {
        perror("malloc");
        exit(EXIT_FAILURE);
    }
    pool->thread_count = size;
    pool->queue = NULL;
    pool->shutdown = false;

    pthread_mutex_init(&pool->queue_mutex, NULL);
    pthread_cond_init(&pool->queue_not_empty, NULL);

    for (size_t i = 0; i < size; i++) {
        pthread_create(&pool->threads[i], NULL, thread_worker, pool);
    }
}

/*** **Neuen Job in den Threadpool einspeisen** ***/
job_id pool_submit(thread_pool* pool, job_function function, job_arg arg) {
    job_queue_entry* new_job = create_job(function, arg);

    pthread_mutex_lock(&pool->queue_mutex);

    if (pool->queue == NULL) {
        pool->queue = new_job;
    } else {
        job_queue_entry* current = pool->queue;
        while (current->next != NULL) {
            current = current->next;
        }
        current->next = new_job;
    }

    pthread_cond_signal(&pool->queue_not_empty);
    pthread_mutex_unlock(&pool->queue_mutex);

    return new_job->id;
}

/*** **Auf einen bestimmten Job warten (`pool_await`)** ***/
void pool_await(job_id id) {
    pthread_mutex_lock(&pool->queue_mutex);
    job_queue_entry* job = pool->queue;

    while (job != NULL && job->id != id) {
        job = job->next;
    }
    
    if (job) {
        pthread_mutex_lock(&job->mutex);
        while (job->status != JOB_DONE) {
            pthread_cond_wait(&job->cond, &job->mutex);
        }
        pthread_mutex_unlock(&job->mutex);
    }

    pthread_mutex_unlock(&pool->queue_mutex);
}

/*** **Thread-Pool zerstören** ***/
void pool_destroy(thread_pool* pool) {
    pthread_mutex_lock(&pool->queue_mutex);
    pool->shutdown = true;
    pthread_cond_broadcast(&pool->queue_not_empty);
    pthread_mutex_unlock(&pool->queue_mutex);

    for (size_t i = 0; i < pool->thread_count; i++) {
        pthread_join(pool->threads[i], NULL);
    }

    // Jobs in der Warteschlange freigeben
    job_queue_entry* current = pool->queue;
    while (current) {
        job_queue_entry* next = current->next;
        pthread_mutex_destroy(&current->mutex);
        pthread_cond_destroy(&current->cond);
        free(current);
        current = next;
    }

    free(pool->threads);
    pthread_mutex_destroy(&pool->queue_mutex);
    pthread_cond_destroy(&pool->queue_not_empty);
}
