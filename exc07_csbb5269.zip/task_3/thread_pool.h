#ifndef THREAD_POOL_H
#define THREAD_POOL_H

#include <stddef.h> // for size_t
#include <pthread.h> // for pthread_t and related functions
#include <stdbool.h> // for bool type
#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>

typedef void* (*job_function)(void*);
typedef void* job_arg;
typedef size_t job_id;

/***
 * This is the stub of a simple job queue.
 */

struct job_queue_entry {
	job_id id; // Unique identifier for the job
	job_function function; // The function to execute
	job_arg argument;      // The argument to pass to the function
	struct job_queue_entry* next; // Pointer to the next job in the queue
};

/***
 * This is the stub for the thread pool that uses the queue.
 * Implement at LEAST the Prototype functions below.
 */

typedef struct {
	pthread_t * threads;
	struct job_queue_entry * queue;
} thread_pool;

// Prototypes for REQUIRED functions
void pool_create(thread_pool* pool, size_t size);
job_id pool_submit(thread_pool* pool, job_function start_routine,
                   job_arg arg); // You need to define a datatype for the job_id (chose wisely).
void pool_await(job_id id);
void pool_destroy(thread_pool* pool);

#endif
