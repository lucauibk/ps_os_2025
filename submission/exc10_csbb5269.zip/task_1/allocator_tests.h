#ifndef ALLOCATOR_TESTS_H
#define ALLOCATOR_TESTS_H

#include <stddef.h>

void test_dummy_allocator(void);
void test_free_list_allocator(void);
void test_best_fit_allocator(void);

#endif
